<?php 

/*
Plugin Name: Scroll To Top Advanced
Description: Scroll Top Advanced plugin allows the visitor to easily scroll back to the top of the page.
Plugin URI: https://www.topdigitaltrends.net/blog
Author: Nasir
Author URI: https://www.topdigitaltrends.net/
Version: 2.5
License: GPL2
Text Domain: Text Domain
Domain Path: Domain Path
*/

/*
    Copyright (C) 2015  Nasir  nasirahmad2010@hotmail.com
*/

require_once('main.php');

?>