=== Scroll Top Advanced - Scroll to ID or Class ===
Contributors: nasir179125
Donate link: https://www.2checkout.com/checkout/purchase?sid=202485641&quantity=1&product_id=1
Tags: scroll to top, back to up, bar, custom icon, fixed button scroller, go-to-top, notification bar, one click scroller, plugin, responsive button,  responsive scroll to top button, scroll, scroll to top plugin, scroll up, scroller, scroll to top plugin, vertical scroller
Requires at least: 3.5
Tested up to: 5.8.2
Stable tag: 2.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

99+ Pre Designs allows the visitor to easily scroll back to the top of the page, also navigate to the specific "ID" or "class".

== Description ==

Scroll Top Advance plugin allows the visitor to easily scroll back to the top of the page. It is based on pure CSS3 with multi effects, icons and custom setting Scroll Top – It is compatible with all modern web browsers
<br>
<br>
Click Here For <a href="http://topdigitaltrends.net/blog" target="_blank">DEMO</a><br> 
Contact For Any Suggestion:-  <b>nasir179125@gmail.com</b>


<h3>Language</h3>
<ul>
	<li>English</li>
</ul>

<h3>Features</h3>
<ul>
	<li>Move to Custom “ID” or “Class”</li>
	<li>Font Awesome Icons</li>
	<li>Custom Text</li>
	<li>Custom Image</li>
	<li>99+ Default Images</li>
	<li>Unlimited Color Variations</li>
	<li>35+ CSS3 Animations</li>
	<li>Color, Background Color, Opacity</li>
	<li>Page Scroll Speed</li>
	<li>Button Styles</li>
	<li>Square, Round, Diamond</li>
	<li>Custom Positions</li>
	<li>Scroll Visibility</li>
	<li>Show/Hide on Mobile</li>
	<li>Replace text with icon (Optional)</li>
	<li>100% Responsive</li>
</ul>

== Installation ==

1. Go to plugins in your dashboard and select 'add new'
2. Search for 'Scroll Top Advanced' and install it
3. Go to 'Scroll Top' on left side of dashboard
4. Fill some additional informations.
5. Now visit your site

== Screenshots ==

1. Admin Setting
2. Easy to use interface.

== Changelog ==

= 2.5 =
* Now all pro features are free.
* Move to Custom “ID” or “Class”
* Custom Text
* Custom Image
* 99+ Default Images
* Show/Hide on Mobile
* Bug fixes

= 2.4 =
* Set Custom Position
* Bug fixes

= 2.2 =
* Bug fixes

= 2.0 =
* Square Button Style
* More Button Positions
* More Button Positions
* Background Color on Hover